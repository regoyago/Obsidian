as with [[waveform period]]

#waveform 
