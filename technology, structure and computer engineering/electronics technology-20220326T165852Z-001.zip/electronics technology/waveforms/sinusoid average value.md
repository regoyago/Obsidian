Given that the alternating sinusoid is symmetricwith respect to the horizontal axis, its average value is always zero

$$X_{dc}=X_{C}=\frac{1}{T}\int^T_0X_msin(\omega t)dt=0$$

[[waveform average value]]
 #waveform 