the waveform amplitude $X_m$
maximum value taken by the signal with respect to its [[waveform average value]]. 
in case the average value of a signal be equal to zero, then its amplitude $X_m$ and its peak value $X_p$ are the same

#waveform