as with [[waveform instantaneous value]]
#waveform 