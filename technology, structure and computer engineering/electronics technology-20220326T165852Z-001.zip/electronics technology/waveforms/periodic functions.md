a periodic signal can fall into one of the following two categories:
- [[alternating signal]]
- [[composite signal]]

#waveform