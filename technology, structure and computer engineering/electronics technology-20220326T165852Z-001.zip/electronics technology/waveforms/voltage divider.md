a [[resistor]] can be used as a voltage divider if it is connected in [[series]]:
the voltage ([[electric potential]]) across each resisitor is proportional to the value of each [[resistor]]
$$V=V_1+V_2+ \ldots + V_n$$ $$V_n=I.R_n$$
#electric_circuit