defined closely to  [[waveform peak value]] $X_{pp}\= 2·X_m$
#waveform 