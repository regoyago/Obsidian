($X_m$)since the sine function is bounded between$±1$ ($|sin(t)| ≤1$),then $±X_m$is the bound for the instantaneous values of the signal, i.e., $|x(t)|≤X_m$. Inthe case of a sinusoidal signal without DC offset (a pure sinusoid), the amplitude andthe peak value are the same
[[waveform amplitude]]
#waveform 