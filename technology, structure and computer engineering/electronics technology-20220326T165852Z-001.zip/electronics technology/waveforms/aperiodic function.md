a [[mathematical function]] in which the signal values do not repeat in a periodic fashion, hence, a time interval from which the signal repeats will never be found
we identify two main non-periodic functions:
- [[step function]]
- [[exponential signal]]

#waveform