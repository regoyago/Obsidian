the composite periodic signal consists of two different signal types, being one of them a constant signal over time, which corresponds to the average value of the composite signal

#waveform