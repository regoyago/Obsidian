the frequency $f$ of a waveform is the number of times that the signal repeats within a second, thus $f=\frac{1}{T}$, the inverse of the [[waveform period]]

#waveform