an alterlating signal is a periodic signal that takes positive and neegative values in alternating fashion
a pure alternating signal is that signal whose average value is 0

#waveform