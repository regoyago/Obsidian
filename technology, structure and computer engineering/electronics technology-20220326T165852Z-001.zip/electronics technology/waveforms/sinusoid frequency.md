like [[waveform frequency]] pulsatance $ω\=2πT\= 2πf$, expressed in rad/s, represents an angular variation over time since the signal runs along an angle of $2π$radians for each time period $T$. 
the angular frequency is also defined as the rate of change of the phaseof a sinusoidal waveform, or as the rate of change of the argument of the sine function
#waveform 