the instantaneous value of a waveform ($x(t)$) is the value taken by the signal for each time instant $t$

#waveform