the waveform ripple or peak-to-peak value $X_{pp}$ is the difference between the maximum and the minimum values of the signal
$X_{pp}=X_{ps}-X_{pi}$

#waveform 