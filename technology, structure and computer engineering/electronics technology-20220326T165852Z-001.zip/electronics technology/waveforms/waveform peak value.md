extreme (maximum or minimum) value taken by the signal. 
- if itcorresponds to the maximum value, then it is denoted as superior peak value $X_{ps}$, or simply, peak value $X_p$ 
- if it corresponds to the minimum value, then it is denoted as inferior peak value $X_{pi}$

#waveform