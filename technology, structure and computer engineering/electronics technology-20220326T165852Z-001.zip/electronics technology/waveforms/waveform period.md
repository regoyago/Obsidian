the period ($T$) of a waveform is the time duration of a single cycle in a repeating event, it is expressed in seconds

#waveform