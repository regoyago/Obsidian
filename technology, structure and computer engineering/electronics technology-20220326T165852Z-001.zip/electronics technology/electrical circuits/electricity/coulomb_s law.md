coulomb's law is a [[law]] of physics that quantifies the amount of [[force]] between two stationaty [[electric charge]], the force known as [[electric force]] or electrostatic force
defined formally: 
$$\vec{F}=K_e*\frac{q_1*q_2}{r^2}\vec{U_r} = F = \frac{1}{4\pi\varepsilon_0}*\frac{q_1*q_2}{r_2}  \ N$$

being $K_e$ [[coulomb's constant]]
and given in [[newtons]]

#electricity
