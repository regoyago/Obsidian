electricity is generally referred to as the presence and flow of [[electric charge]]
it is also used as a synonym to electrical energy, even though they aren't equal:
electricity is a transmission medium for electrical energy (similar to how water is a medium for wave energy)

#electricity