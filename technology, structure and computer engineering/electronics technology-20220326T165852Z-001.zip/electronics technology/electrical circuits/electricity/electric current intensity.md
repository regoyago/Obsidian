the current intensity is the quantity of [[electric charge]] which passes in a [[electrical conductor]] by unit of time it is measured in a [[ampere]] $A$
it is the measurement of [[electric current]] over time in an specific point

formally:
$$I=\frac{dQ}{dt} \ \ A$$

being $dQ$ the net charge flowing though a section during a differential time $dt$

#electricity