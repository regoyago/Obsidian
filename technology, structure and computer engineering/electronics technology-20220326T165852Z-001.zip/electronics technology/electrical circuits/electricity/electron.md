the electron is a [[subatomic particle]], symbol $e^-$ or $\beta ^-$, whose [[electric charge]] is negative one [[elementary charge]]

electrons belong to the first generation of the [[lepton]] [[particle family]], and are generally thought to be elementary particles, since they have no known components of substructure

it is known to have an approximated mass of $9.1093837015(28)×10^{−31} kg$

