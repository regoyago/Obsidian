the amprere $A$, often shortened to amp is the [[base unit]] of [[electric current]] in the [[international system of units]]

the ampere has been defined as one [[coulomb]] of charge per [[second]]

#electricity