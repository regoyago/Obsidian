ohm's [[law]] states that the [[electric current]] through a [[electrical conductor]] between two points is directly [[proportional]] to the [[electric potential]] across the two points
introducing the concept of [[electrical resistance]], the following equation is obtained
$$I=\frac{V}{R}=\frac{V_a-V_b}{R}$$

ohm's law is an empirical relation which accurately describes the conductivity of the vas majority of electrically conductive materials, this materials are called ohmnic materials

#electricity
