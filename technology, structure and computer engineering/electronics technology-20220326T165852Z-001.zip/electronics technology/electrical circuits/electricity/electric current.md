electric current is a physical phenomenon caused by a stream of  particles with [[electric charge]] moving through an [[electrical conductor]] or space
it is measured as the net rate of flow of [[electric charge]] through a surface or into a volume, [[electric current intensity]]
the moving particles are called [[charge carriers]], in  an [[electric circuit]], they are generally [[electrons]] moving though a [[wire]]

the unit in which the electric current is measured is the [[ampere]] $A$, 

although we refer to the direction of the current in [[electrical conductor]], [[electric current]] is a [[scalar magnitude]], thus, when we refer to the direction, we are indicating the direction of the [[flow]] due to the positive-[[charge carriers]],  therefore the direction of the current is given by the direction of the movement of the positive charge carriers, by convention
since in metallic conductors the [[charge carriers]] are electrons, the [[direction]] of the current is opposed to the movement of the electrons [^1]

the [[electric current]] and [[electric potential]] have opposite [[direction]]

#electricity

[1]: this means that whether we take into account a positive or a negative charge, the result will be the same, thus there is no need to worry about the sign of the charge carriers when studying the effects produced by an electric current 