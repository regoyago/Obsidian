the electrical resistance of an object is a measure of its opposition to the flow of [[electric current]], the [[multiplicatreive ciprocal quantity]] is the [[electrical conductance]]
the electric resistance can be calculated as:
$$\frac{V_1}{I_1}=\frac{V_2}{I_2}=\frac{V_3}{I_3}= R \ \ \Omega$$
it is measured in  [[ohm]] $\Omega$

resistance is not dependant on the [[electric potential]] or [[electric current intensity]], but on the shape, size and composition of the material of the [[electrical conductor]]
the resistance can be obtained as
$$R=\rho \frac{I}{S}$$
being $I$ the intensity of the current, $S$ a section with a constant area and $\rho$ the resistivility of a material
#electricity