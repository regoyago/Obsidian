the electric constant, also known as vacuum permittivity ($\varepsilon_0$) has a value of:
($\varepsilon_0 = 8.8541878128(13)×10^{-12})$
with a relative uncertainty of $1.5×10^{-10}$
the value of the absolute dielectric permittivity of a classical vacuum

the vacuum permitivity can be defined as the cpacity of an [[electric field]] to permeate a vacuum
this constatn relates the units for [[electric charge]] to mechanical quantities, such as [[force]]

#electricity