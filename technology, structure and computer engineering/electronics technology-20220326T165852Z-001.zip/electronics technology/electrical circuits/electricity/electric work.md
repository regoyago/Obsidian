the [[electric force]] s a [[central force]],  thus it will also be a [[conservative force]], so, the work neede to carry an [[electric charge]] $q$, from a point $A$ to another point $B$ only dependes on the initial and final positions
formally:
$$W=\int^{B}_{A}\vec{F}.d\vec{r}=\int^{B}_{A} \frac{K.q_1.q_2}{r^2}=K.q_1.q_2.\int^{B}_{A}\frac{dr}{r^2}=K.q_1.q_2.\Big[-\frac{1}{r} \Big]^B_A=K.q_1.q_2.\Big(\frac{1}{r_b}-\frac{1}{r_a}\Big) \ \ J$$

using [[integration]], [[derivation]]
using the definition of [[electric force]]
given in [[joules]]

#electricity