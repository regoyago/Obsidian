The constant $K_e$ is known as coulomb's constant and is equal to 

$$K_e=\frac{1}{4\pi\varepsilon_0} \ \ \ \frac{N*m^2}{C^2}$$ 
where $\varepsilon_0$ is the [[electric constant]]
the value of $K_0$ in the air is approximately $9.0*10^9$

#electricity