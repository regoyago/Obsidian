the central force of the [[electric field]] is defined formally by [[coulomb's law]]

#electricity