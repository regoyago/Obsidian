the coulomb $C$ is the [[base unit]] of [[electric charge]] in the [[international system of units]]
being defined precisely as $1.602176634*10^{19}$ [[elementary charge]]

#electricity