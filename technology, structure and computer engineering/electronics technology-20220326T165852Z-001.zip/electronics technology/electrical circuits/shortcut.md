a shortcut is the connection between two points of a circuit by means of an ideal [[electrical conductor]]
as $R=0$, the voltage across a shortcut is always zero, independently from the current intensity 
an [[open circuit]] is the absence of a shortcut or any otheer connection

#electric_circuit