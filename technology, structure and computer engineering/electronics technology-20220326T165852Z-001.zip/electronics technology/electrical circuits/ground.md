ground or earth is the reference point in an electrical circuit from which [[electric potential]] is measured, a common return path for [[electric current]], or a direct physical connection to the earth

#electric_circuit 