an electric circuit it a path in which a [[electron]] (or set of) forms a [[electric potential]] or [[electric current]]

the point where those electrons enter an electrical circuit is called the [[source]], and where they leave it, [[ground]] or [[return]], the part in between both starting and ending points is called the load

#electric_circuit