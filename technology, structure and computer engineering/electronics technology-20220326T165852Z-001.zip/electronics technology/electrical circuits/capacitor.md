a capacitor is one of the different [[passive electrical component]] regularly used
a capacitor is a two-terminal component used to temporarily store [[electric energy]] in an electric field
then energy is stored in a capacitor, an [[electric field]] appears abd such energy is tored to that field
the porperty characterizing the possibilities of a capacitor to store energy is the [[electric capacitance]]

a capacitor is a device consisting of two closely placed conductors insulated between them
independlently from the  shape of the capacitor, each of the ahorementioned conductors is called plate

a capacitor can be charged connecting its terminals to those of a battery [[charge of a capacitor]]