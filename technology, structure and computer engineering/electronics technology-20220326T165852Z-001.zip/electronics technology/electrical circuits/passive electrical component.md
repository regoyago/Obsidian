pasive electrical components are defined as those components that only consume or store electricity 

#electric_circuit