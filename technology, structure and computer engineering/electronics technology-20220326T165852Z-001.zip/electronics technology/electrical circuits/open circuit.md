an open circuit is the absence of a connection between two points in a [[electric circuit]], thus, in an open circuit the [[electric current intensity]] is always $0$, current can't flow though an open circuit

#electric_circuit