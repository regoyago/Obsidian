[[charge carriers]] lose energy when colliding inside the [[resistor]], and such collisions are responsible for the [[electrical resistance]] exhibited by the materials
this energy loss produces a temperature increase inside the conductor
if such temperature is greater than the outside of the [[electrical conductor]], then a heat transference takes place
it is said that [[electric energy]] in a [[resistor]] is dissipated as heat

in stationary conditions there is an equilibrium between the energy dissipated inside the [[conductor]] and the energy that is transferred outside the [[conductor]]. at this point, the temperature of the [[resistor]] reaches also its equilibrium and keeps constant. in this, case the [[resistor]] is not able to dissipate the heat originated inside, then the temperature will continue increasing until the [[resistor]] is destroyed

#electric_circuit