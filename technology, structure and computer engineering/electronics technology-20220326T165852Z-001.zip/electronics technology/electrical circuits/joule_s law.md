joules's [[law]] is a mathimatical description of the rate at which [[electrical resistance]] in a circuit convers [[electric energy]] into [[heat energy]], that is, the [[power dissipated]] as [[heat energy]]

$$P_R=I^2.R \ \ \ W$$

expressed in [[watt]]

#electric_circuit