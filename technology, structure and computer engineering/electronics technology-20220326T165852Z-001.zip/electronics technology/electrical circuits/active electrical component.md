active electrical components are defined as those components that not only consume or store electricity , but can deliver it
[[dc voltage source]]
[[dc current source]]

#electric_circuit