a  wire is a single flexible strand that is used to bear mechanical or as [[electrical conductor]]
#electric_circuit