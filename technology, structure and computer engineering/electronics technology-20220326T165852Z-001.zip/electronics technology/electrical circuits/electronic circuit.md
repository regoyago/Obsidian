an electronic circuit is composed of individual electronic components, such as 
- [[resistor]]
- [[transistor]]
- [[capacitor]]
- [[inductor]]
- [[diode]]

all connected though a [[wire]] or [[trace]] though which [[electric current]] can flow
in order to be considered electronic circuit and not [[electric circuit]], it must present at least one [[active electrical component]], not only [[passive electrical component]]

#electric_circuit