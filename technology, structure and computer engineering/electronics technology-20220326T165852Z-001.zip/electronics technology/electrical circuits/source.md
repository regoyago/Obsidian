we differentiate two main sources in our circuits:
[[dc current source]]
[[dc voltage source]]

#electric_circuit