let $f: \mathbb{R} \rightarrow \mathbb{R}$, we say that the [[mathematical function]] is periodic, with  [[period]] $T$, if:

$$f(x)=f(x+T) \forall x\in \mathbb{R}$$

#function_analysis