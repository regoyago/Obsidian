we say that a [[mathematical function]] is odd if 
$$f(x)=-f(x) \ \ \forall x\in \mathbb{D}(f)$$

this name comes from the fundamental monomials with  
odd exponent ($x, x^3, x^5,...$), since they have odd symmetry.

#function_analysis