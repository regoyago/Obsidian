we say that a [[mathematical function]] $f$ is even if 
$$f(x)=f(-x) \ \ \forall x\in \mathbb{D}(f)$$

this name comes from the fundamental monomials with  
even exponent ($x^2, x^4, x^6,\ldots$), they have even symmetry
#function_analysis