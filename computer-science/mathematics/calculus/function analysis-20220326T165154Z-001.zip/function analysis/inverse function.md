let $f:A\subset \mathbb{R}\rightarrow \mathbb{R}$ be an [[injective]] function
then, exactly one function $h:Im(f)\rightarrow \mathbb{R}$ will exist such that $h(f(x))= x \ \ \ \ \forall x\in A$ 
[[inverse]]

#function_analysis