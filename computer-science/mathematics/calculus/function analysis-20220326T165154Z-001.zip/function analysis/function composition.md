[[composition]]
#function_analysis