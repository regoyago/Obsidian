in mathematics, trigonometric functions are [[mathematical function]]s with values over the [[real number]]s which take into account [[trigonometry]] and [[trigonometric identities]]

#trigonometry 