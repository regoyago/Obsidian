int [[trigonometry]]the law of tangents, is an alternative to the [[law of cosines]] when solving for the unknown edges of a [[triangle]], by providing simpler calculations when using trigonometric tables
it is given by:
$$\frac{a-b}{a+b}= \frac{tan[\frac{1}{2}(A-B)]}{tan[\frac{1}{2}(A+B)]}$$

#trigonometry 