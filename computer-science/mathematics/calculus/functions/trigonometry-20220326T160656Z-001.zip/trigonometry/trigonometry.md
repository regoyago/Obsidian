trigonometry is a branch of mathematics that studies relationships between side lengths and angles of triangles

trigonometry is known for its [[trigonometric identities]]

trigonometric ratios:
- [[sine]]
- [[cosine]]
- [[tangent]]


reciprocals of the trigonometric ratios: 
- [[cosecant]]
- [[secant]]
- [[cotangent]]

inverses of the trigonometric ratios:
- [[arcsine]]
- [[arccosine]]
- [[arctangent]]


laws:
- [[law of sines]]
- [[law of cosines]]
- [[law of tangents]]

[[trigonometric identities]]

#trigonometry 