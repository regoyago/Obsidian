the hypotenuse  is the longest side of a [[right triangle]], the side opposite the right anfle

the length of the hypotenuse can be found using the [[pythagorean theorem]]