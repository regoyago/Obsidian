in mathematics, the pythagorean theorem is a fundamental relation in euclidean geometry among the three sides of a [[right triangle]]

it states that the area of the square whose side is the [[hypotenuse]] is equal to the sum of the areas of the squares on the other two sides

this theorem can be written as en equation relating the length of the sides $a, b$ and $c$ :

$$a^2+b^2=c^2$$